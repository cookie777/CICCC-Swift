//
//  Person.swift
//  TSanExample
//
//  Created by Derrick Park on 2021-06-07.
//

import Foundation

open class Person {
  private var firstName: String
  private var lastName: String
  
  public init(firstName: String, lastName: String) {
    self.firstName = firstName
    self.lastName = lastName
  }
  
  open func changeName(firstName: String, lastName: String) {
    randomDelay(maxDuration:  0.2)
    self.firstName = firstName
    randomDelay(maxDuration:  1)
    self.lastName = lastName
  }
  
  open var name: String {
    "\(firstName) \(lastName)"
  }
}

func randomDelay(maxDuration: Double) {
  let randomWait = UInt32.random(in: 0..<UInt32(maxDuration * Double(USEC_PER_SEC)))
  usleep(randomWait)
}

class ThreadSafePerson: Person {
  
  let isolationQueue = DispatchQueue(label: "com.example.person.isolation", attributes: .concurrent)
  
  override func changeName(firstName: String, lastName: String) {
    isolationQueue.async(flags: .barrier) {
      super.changeName(firstName: firstName, lastName: lastName)
    }
  }
  
  // Use .sync to safely access value
  override var name: String {
    isolationQueue.sync {
      super.name
    }
  }
}
