//
//  TableViewController.swift
//  TSanExample
//
//  Created by Derrick Park on 2021-06-07.
//

import UIKit

class TableViewController: UITableViewController {
  
  let nameList = [("Charlie", "Cheesecake"), ("Delia", "Dingle"), ("Eva", "Evershed"), ("Freddie", "Frost"), ("Gina", "Gregory")]
  let workerQueue = DispatchQueue(label: "com.example.worker", attributes: .concurrent)
  
  var users = [String]()
  
  override func viewDidLoad() {
    super.viewDidLoad()
//    changeNameDataRace()
    changeNameSafely()
  }
  
  func changeNameSafely() {
    let threadSafeNameGroup = DispatchGroup()
    let threadSafePerson = ThreadSafePerson(firstName: "Anna", lastName: "Adams")
    
    for (idx, name) in nameList.enumerated() {
      workerQueue.async(group: threadSafeNameGroup) { [unowned self] in
        usleep(UInt32(10_000 * idx))
        threadSafePerson.changeName(firstName: name.0, lastName: name.1)
        self.users.append(threadSafePerson.name)
        //print("Current threadsafe name: \(threadSafePerson.name)")
      }
    }
    
    threadSafeNameGroup.notify(queue: DispatchQueue.main) { [unowned self] in
      print("Final threadsafe name: \(threadSafePerson.name)")
      self.tableView.reloadData()
    }
  }
  
  func changeNameDataRace() {
    let nameChangingPerson = Person(firstName: "Alison", lastName: "Anderson")
    let nameChangeGroup = DispatchGroup()
    
    for (idx, name) in nameList.enumerated() {
      workerQueue.async(group: nameChangeGroup) { [unowned self] in
        usleep(UInt32(10_000 * idx))
        nameChangingPerson.changeName(firstName: name.0, lastName: name.1)
        self.users.append(nameChangingPerson.name)
        // print("Current Name: \(nameChangingPerson.name)")
      }
    }
    
    nameChangeGroup.notify(queue: DispatchQueue.main) { [unowned self] in
      print("Final name: \(nameChangingPerson.name)")
      self.tableView.reloadData()
    }
    
    nameChangeGroup.wait()
  }
  
  // MARK: - Table view data source
  
  override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
    return users.count
  }
  
  override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
    cell.textLabel?.text = users[indexPath.row]
    
    return cell
  }
  
}
