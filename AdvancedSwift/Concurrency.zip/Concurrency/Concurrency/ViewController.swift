//
//  ViewController.swift
//  Concurrency
//
//  Created by Derrick Park on 2021-05-31.
//

import UIKit

class ViewController: UIViewController {

  let userQueue = DispatchQueue.global(qos: .userInitiated)
  let defaultQueue = DispatchQueue.global()
  let mainQueue = DispatchQueue.main  // serial
  
  let mySerialQueue = DispatchQueue(label: "com.example.serialWorker")
  let workerQueue = DispatchQueue(label: "com.example.worker", attributes: .concurrent)
  
  override func viewDidLoad() {
    super.viewDidLoad()
//    userQueue.async {
//      self.task1()
//    }
//
//    userQueue.async {
//      self.task2()
//    }
    
//    workerQueue.async {
//      self.task1()
//    }
//    workerQueue.async {
//      self.task2()
//    }
    
    // dispatchPrecondition(condition: .onQueue(.main))
    
//    mySerialQueue.sync {
//      self.changeValue()
//    }
//    print(value)
   
    let workItem = DispatchWorkItem { self.task1() }
    userQueue.async(execute: workItem)
    // if the current thread really needs workItem to finish before it can continue,
    // call wait to tell the system to give it a higher priority.
    if workItem.wait(timeout: .now() + 2) == .timedOut {
      print("I got tired of waiting.")
    } else {
      print("work item completed")
    }
    
//    let backgroundWorkItem = DispatchWorkItem { self.task1() }
//    let updateUIWorkItem = DispatchWorkItem { self.task2() }
//    userQueue.async(execute: backgroundWorkItem)
//    // userQueue.async(execute: updateUIWorkItem)
//    backgroundWorkItem.notify(queue: mainQueue, execute: updateUIWorkItem)
//
//    if !updateUIWorkItem.isCancelled {
//      updateUIWorkItem.cancel()
//    }
  }
  
  var value = 40
  func changeValue() {
    sleep(2)
    value = 0
  }

  func task1() {
    print("Task 1 started")
    sleep(3)
    print("Task 1 finished")
  }
  
  func task2() {
    print("Task 2 started")
    print("Task 2 finished")
  }
  
}

