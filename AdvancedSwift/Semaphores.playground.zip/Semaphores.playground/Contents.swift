import UIKit

let backgroundQueue = DispatchQueue.global(qos: .utility)
let semaphore = DispatchSemaphore(value: 5)

backgroundQueue.async {
  print("Task 1 - wait")
  semaphore.wait()
  print("Task 1 - wait finished")
  sleep(2)
  print("Task 1 - completed")
  semaphore.signal()
}

backgroundQueue.async {
  print("Task 2 - wait")
  semaphore.wait()
  print("Task 2 - wait finished")
  sleep(2)
  print("Task 2 - completed")
  semaphore.signal()
}

backgroundQueue.async {
  print("Task 3 - wait")
  semaphore.wait()
  print("Task 3 - wait finished")
  sleep(2)
  print("Task 3 - completed")
  semaphore.signal()
}

func dataTask_Group_Semaphore(with url: URL,
  group: DispatchGroup, semaphore: DispatchSemaphore,
  completionHandler: @escaping (Data?, URLResponse?, Error?) -> Void) {
  
  semaphore.wait()
  group.enter()
  
  URLSession.shared.dataTask(with: url) { data, response, error in
    defer {
      group.leave()
      semaphore.signal()
    }
    completionHandler(data, response, error)
  }.resume()

}


let group = DispatchGroup()
let queue = DispatchQueue.global(qos: .utility)
var images: [UIImage] = []

for id in 0..<100 {
  guard let url = URL(string: "https:.../\(id)") else { continue }
  // DONE: Call dataTask_Group_Semaphore
  dataTask_Group_Semaphore(with: url, group: group, semaphore: semaphore) {
    data, _, error in
    if error == nil, let data = data, let image = UIImage(data: data) {
      images.append(image)
    }
  }
}

group.notify(queue: DispatchQueue.main) {
  print("Update UI")
  images
}
